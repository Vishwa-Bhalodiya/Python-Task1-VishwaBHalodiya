from django.http import HttpResponse
import csv
from .models import YourModel

def export_csv(request):
    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = 'attachment; filename="yourmodel_data.csv"'

    writer = csv.writer(response)
    writer.writerow(['Field1', 'Field2', 'Field3'])

    for obj in YourModel.objects.all():
        writer.writerow([obj.field1, obj.field2, obj.field3]) 

    return response
