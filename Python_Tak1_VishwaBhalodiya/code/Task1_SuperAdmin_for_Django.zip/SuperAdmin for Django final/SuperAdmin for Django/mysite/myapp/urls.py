from django.urls import path
from . import views

urlpatterns = [
    path('export_csv/', views.export_csv, name='yourmodel_export_csv'),
]
